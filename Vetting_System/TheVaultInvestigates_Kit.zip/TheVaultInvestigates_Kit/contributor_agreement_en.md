# TruthDrop Portal – Contributor Agreement (Plain Language)

To protect everyone’s safety and the integrity of investigations, portal access requires agreeing to the following terms.

## 1. Confidentiality of work‑in‑progress

- I will not screenshot, copy, or publicly share internal discussions, draft case files, or partial findings from the portal without explicit permission from the portal host.
- I understand that leaking half‑baked allegations can harm real people and undermine the project.

## 2. No harassment or weaponization

- I will not use portal information to harass, dox, or threaten individuals or organizations.
- I will not use the portal to pursue personal grudges or vendettas.
- I understand that if I break this, my access can be removed.

## 3. Anonymity and identity

- I may use a handle instead of my real name inside the portal.
- If my contributions meaningfully shape a public article or case, I can choose to be:
  - Credited by handle,
  - Credited as “anonymous collaborator,” or
  - Not credited at all.

## 4. Use of my contributions

- I understand that my contributions (links, notes, summaries, timelines) may be used in TruthDrop / The Vault Investigates articles and outputs, in line with the mission of documenting poverty-related fraud and injustice.

## 5. No guarantees

- Portal access is at the host’s discretion. Access may be paused or removed to protect others, manage safety, or keep the space healthy.
- The host cannot offer legal advice or personal security guarantees.

By selecting “I agree” on the application form, I confirm that I understand and accept these terms.
