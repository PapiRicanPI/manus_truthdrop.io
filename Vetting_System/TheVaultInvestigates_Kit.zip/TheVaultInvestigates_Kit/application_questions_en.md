# TruthDrop Portal – Application Questions (English)

Use these questions in your form tool (Google Forms, Typeform, etc.).

1. **Preferred handle inside the portal**  
   Short answer.

2. **Email for invitations and updates**  
   Short answer. (State you will not share or sell it.)

3. **Why do you want to join The Vault Investigates / TruthDrop portal?**  
   Long answer (3–10 sentences).

4. **How would you describe yourself?**  
   Multiple choice (allow multi-select):
   - Journalist
   - Researcher / academic
   - Former or current NGO / charity / development worker
   - Donor / concerned citizen
   - Lawyer / legal worker
   - Other (please specify)

5. **How much time could you realistically spend per month?**  
   - 1–2 hours
   - 3–5 hours
   - 6+ hours
   - I just want to read quietly

6. **What kind of work are you comfortable doing?**  
   Checkboxes:
   - Saving and tagging articles / links
   - Checking basic facts (dates, amounts, locations)
   - Looking up public filings / budgets
   - Writing short summaries or timelines
   - Only reading and reacting in comments

7. **Share one public story (link) about poverty, aid, or charity that concerns you. What would you want to investigate further about it?**  
   Long answer.

8. **When would you *not* publish or amplify an accusation, even if it fits your suspicions?**  
   Long answer.

9. **Conflicts of interest and safety**  
   - “Have you ever worked for, volunteered with, or been helped by an organization you might want to write about? If yes, briefly explain so we can manage conflicts of interest.”  
   Long answer.

10. **Contributor Agreement (required)**  
   Show the agreement text from `contributor_agreement_en.md` and ask:  
   - “I have read and agree to the Contributor Agreement.” (Yes / No)  
   Make **Yes** required to submit.

11. **Optional: Ko‑fi support**  
   - “Are you currently an Archive Builders supporter on Ko‑fi or considering it?”  
   - Options: “Already supporting / Planning to / Not now / Prefer not to say.”
