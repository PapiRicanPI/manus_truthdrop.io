# The Vault Investigates: Call for Contributors to the TruthDrop Portal

I’m launching **The Vault Investigates** – a small, focused effort to build an anonymous investigation portal called **TruthDrop** for people who want to seriously track poverty-related fraud and turn scattered receipts into documented cases and stories.

This is not a fan club. It’s a working archive and investigation room that will feed future TruthDrop pieces and long-term case files.

## What the TruthDrop portal is

- A private workspace where we:
  - Store news-scan hits, NGO documents, and other receipts.
  - Build case timelines so stories don’t die after one headline.
  - Track outcomes and follow-ups on allegations that affect people in poverty.

- A place where collaborators can:
  - Propose leads.
  - Help check sources.
  - Suggest angles for future stories.

## Who this is for

- People who like documents, not just outrage.
- People willing to read primary sources and live with nuance.
- People who understand that false or sloppy accusations can hurt real people.

Who this is **not** for:

- Anyone seeking a place to harass, dox, or run personal vendettas.
- People expecting free personal consulting or therapy.
- People looking for quick clout rather than careful work.

## Anonymity and safety

- You do **not** need to use your real name. Choose a handle.
- Internal discussions and draft cases are treated as confidential working material.
- No screenshots or reposting of internal material without explicit permission.

## How to apply

I’m starting with a small group (~25 people) so that the space stays safe and high-signal.

1. Fill out this short questionnaire:  
   **[APPLICATION FORM LINK]**
2. Read and agree to the Contributor Agreement at the end.
3. I’ll review responses in waves and send invitations to the first cohort.

If you don’t hear back immediately, it doesn’t mean “no forever”; it means I’m moving slowly to keep the space healthy.

## About money (optional support)

Access to the investigative portal will stay free for selected collaborators.

If you’re in a position to help cover tools, hosting, and some of the time it takes to run this, there’s an optional **Archive Builders** tier on Ko‑fi connected to **The Vault Investigates**. It doesn’t buy influence over what we publish; it simply makes more investigations possible.

If money is tight, please stay on the free list and keep reading. Your attention and care with these stories already helps.

— [Your handle]
