# The Vault Investigates – Campaign Overview

## Purpose

Build a small, serious community of anonymous collaborators who help investigate poverty-related fraud, document cases, and feed material into the TruthDrop portal and related stories.

## Core goals

- Recruit 20–30 high-signal collaborators, not a large open community.
- Protect anonymity and safety for all contributors.
- Prevent exploitation of time and emotional labor.
- Create a repeatable application → vetting → portal access workflow.
- Offer an optional support tier (Ko‑fi) without begging.

## Channels

- Substack post(s)
- Application form (English + Tagalog + Puerto Rican Spanish)
- Internal database (SQLite via Beekeeper Studio) to track applicants and status
- Ko‑fi membership tier

## Key messages

- Anonymous, evidence-focused investigative space.
- Not a fan club, not a harassment space.
- Access is by application and can be revoked.
- Support is optional but directly funds tools and time.
