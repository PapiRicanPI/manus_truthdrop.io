-- TruthDrop Portal – Applicant Tracking Tables

CREATE TABLE IF NOT EXISTS portal_applicants (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  handle          TEXT NOT NULL,
  email           TEXT NOT NULL,
  self_description TEXT,
  time_commitment TEXT,
  work_types      TEXT,
  story_link      TEXT,
  story_notes     TEXT,
  red_line_answer TEXT,
  conflicts       TEXT,
  ko_fi_status    TEXT,
  agreement_accepted INTEGER DEFAULT 0,
  status          TEXT DEFAULT 'pending',
  notes           TEXT,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS portal_status_changes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  applicant_id  INTEGER NOT NULL,
  old_status    TEXT,
  new_status    TEXT,
  changed_by    TEXT,
  reason        TEXT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(applicant_id) REFERENCES portal_applicants(id)
);
