# Ko‑fi “Archive Builders” Tier – Copy

**Tier name:** Archive Builders  
**Suggested price:** $5–$8/month or $50/year

## Description (short)

Help keep **The Vault Investigates** and the **TruthDrop** portal running. This tier supports tools, hosting, and the time it takes to turn raw leads into documented poverty‑fraud cases and stories.

## What you get

- Monthly behind‑the‑scenes note: what we’re investigating, what stalled, what moved.
- Occasional early looks at case timelines and story outlines.
- Invitation to occasional “case clinic” sessions where we walk through a case in progress.

## What you *don’t* get

- No control over which cases we pursue or what conclusions we reach.
- No special ability to target individuals or organizations.

Support is optional. If money is tight, please stay on the free list and keep reading.
