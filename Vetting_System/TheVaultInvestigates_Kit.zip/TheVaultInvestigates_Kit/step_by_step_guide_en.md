# The Vault Investigates – Step‑by‑Step Campaign Guide

## Phase 1 – Setup

1. Create applicant tables in SQLite using `applicant_database_schema.sql`.
2. Set up Ko‑fi “Archive Builders” tier using `ko_fi_tier_copy_en.md`.
3. Build the application form using `application_questions_en.md` and `contributor_agreement_en.md`.
4. Create and publish the Substack post from `substack_invitation_post_en.md`.

## Phase 2 – Intake and tracking

1. Export form responses as CSV and import into `portal_applicants`.
2. Review applications; set status to `invited`, `active`, or `rejected`.
3. Record changes in `portal_status_changes`.
4. Email invitations to selected applicants.

## Phase 3 – Ongoing

1. Review new applications on a schedule.
2. Pause or remove access if contributor rules are broken.
3. Publish periodic Substack updates on investigations and how support is used.
