# The Vault Investigates / TruthDrop – Social Media Packet (EN)

## Core blurb (short)

Building **The Vault Investigates**, an anonymous portal called **TruthDrop** to track poverty‑fraud: leaked receipts, forgotten news, buried reports.

Looking for ~25 people who like documents more than drama.

Apply to join the TruthDrop portal: [APPLICATION LINK]

Hashtags: #TheVaultInvestigates #TruthDrop #Poverty #Fraud #Accountability

## Substack-reader post

[...you can paste the longer versions you prefer here...]
